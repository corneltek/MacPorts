
core, events

	Support packages for initialization, finalization, and
	timer-driven event support.
