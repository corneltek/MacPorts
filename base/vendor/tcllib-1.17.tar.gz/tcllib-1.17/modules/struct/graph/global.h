/* struct::graph - critcl - global declarations
 */

#ifndef _G_GLOBAL_H
#define _G_GLOBAL_H 1

#include "tcl.h"
#include <ds.h>

const char* gg_new (Tcl_Interp* interp);

#endif /* _G_GLOBAL_H */

/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * fill-column: 78
 * End:
 */
