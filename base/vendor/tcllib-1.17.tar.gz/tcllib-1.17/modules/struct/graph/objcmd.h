/* struct::graph - critcl - layer 2 declarations
 * Support for graph methods.
 */

#ifndef _G_OBJCMD_H
#define _G_OBJCMD_H 1

#include "tcl.h"

int g_objcmd (ClientData cd, Tcl_Interp* interp, int objc, Tcl_Obj* CONST* objv);

#endif /* _G_OBJCMD_H */

/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * fill-column: 78
 * End:
 */
